import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'exlchf8o',
    dataset: 'production',
  },
})
